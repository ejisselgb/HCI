

$(document).ready(function() {
 
  $("#owl-demo").owlCarousel({
    jsonPath : "json/data.json" 
  });
 
});

