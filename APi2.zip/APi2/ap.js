var apiurl = "http://www.omdbapi.com/?apikey=35400f1e&"

function getInfoMovie(url, string){
	return new Promise(function(resolve, reject){
		var request = new XMLHttpRequest();
		request.open('GET', url + string, true);
		request.onload = function (){
		var data = JSON.parse(this.response);
		resolve(data)
		}
	request.send();
	});
}

function searchMovie(){
	console.log("a");
	/*console.log(data.Title, data.Year, data.Poster);*/
	var string = document.getElementById('busqueda').value
	var p = getInfoMovie(apiurl, "t="+string)
	p.then((data)=>{
		/*console.log(data.Title, data.Year, data.Poster);*/
		document.getElementById('title123').innerHTML = data.Title;
		document.getElementById("imagen12").src= data.Poster;
		document.getElementById("sinopsis").innerHTML = data.Plot;

	});
}

/*getInfoMovie(apiurl, "t=nemo")*/

