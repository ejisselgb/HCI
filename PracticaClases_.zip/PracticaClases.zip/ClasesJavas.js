class Movie{

	constructor(name,year,likes){

		console.log();
		this.name = name;
		this.year = year;
		this.likes = likes;
	}	

	showInfo(){
		console.log('nombre: '+ this.name +' '+ 'year: ' + this.year + 'likes: ' + this.likes)
	}

}


var mo = new Movie('h','123123','3')
mo.showInfo()

class Serie extends Movie{
	showInfo(){
		console.log('nombre: '+ this.name +' '+ 'year: ' + this.year)

	}
}


var seriesita = new Serie("h1", "h2")
seriesita.showInfo()

var apiurl = "http://www.omdbapi.com/?apikey=2cbac9d4&t=Casablanca"