
var apiurl = "http://www.omdbapi.com/?apikey=2cbac9d4&";

function infoMovie(url, string){
	var request = new XMLHttpRequest();
	request.open('GET',url + string, true);
	request.onload = function(){
			var data = JSON.parse(this.response);
			console.log(data);
	};
	request.send();
}

infoMovie(apiurl,"t=Ben-Hur");

