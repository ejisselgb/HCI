import React, { Component } from 'react';
import { FlatList, StyleSheet, Text, View, Button, ScrollView, TextInput, DatePickerAndroid, TouchableOpacity, Alert, Picker, Image} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';

class Med extends Component {

  constructor(props) {
      super(props);
      this.state = { text: '', tel: '' };
    }

  static navigationOptions = {
      title: 'Agendar cita',
      headerStyle: {
        backgroundColor: '#37b7ff',
      },
      headerTitleStyle:{
        color: '#ffffff'
      },
      headerTintColor: '#ffffff'
  };

  openDatePicker() {
      try {
        DatePickerAndroid.open({
          date: new Date()
        }).then(date => {
          if (date.action !== DatePickerAndroid.dismissedAction) {
            const finalDate = `${date.month + 1} ${date.day} ${date.year}`;
          }
        });
      } catch ({ code, message }) {
        console.warn('No se pudo abrir el calendario', message);
      }
    }

    selectAppointment(){

      Alert.alert(
      'Su cita ha sido agendada',
      'Revise los datos',
      [
        {
          text: 'Cancelar',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => console.log('OK Pressed')},
      ],
      {cancelable: false},
    );
      console.log("Registrar mi cita");
    }

  render() {
      return (
        <ScrollView>
        <View style={styles.container}>
          
          
          <Text style={styles.text} >Listado de medicamentos</Text>
          <Icon style={styles.icono}

              name="ambulance"
              color="#9e9e9e"
              size={30}
              
          />

          <Icon style={styles.icono2}

              name="ambulance"
              color="#9e9e9e"
              size={30}
              
          />

          <Icon style={styles.icono3}

              name="ambulance"
              color="#9e9e9e"
              size={30}
              
          />

          <Icon style={styles.icono4}

              name="ambulance"
              color="#9e9e9e"
              size={30}
              
          />

          <View style={styles.lista}>
            <FlatList
                data={[
                  {key: 'Dolex'},
                  {key: 'Aspirina'},
                  {key: 'Albendazol'},
                  {key: 'Acitretina'},
                  ]}
          renderItem={({item}) => <Text style={styles.item}>{item.Icon}{item.key} </Text>}
            />
          </View>

         

        </View>
        </ScrollView>
      );
  }
}

const styles = StyleSheet.create({
  icono: {
    left:280,
    top: 130
  },

  icono2: {
    left:280,
    top: 170
  },

  icono3: {
    left:280,
    top: 200
  },


  icono4: {
    left:280,
    top: 230
  },

  text: {
    textAlign:'center',
    fontSize: 20
  },

lista: {
  alignItems: 'center'

},
item: {
    padding: 19,
    fontSize: 19
 
  },

 buttonPress: {
    alignItems: 'center',
    backgroundColor: '#6885FF',
    padding: 10,
    marginTop: 30
 },
 textButton: {
  color: "#fff",
    fontSize: 18,
    fontWeight: "600"
 },
 container: {
  marginTop: 20
 },
 img:{
  marginLeft: '35%',
  width: 110,
  height: 110,
  resizeMode: "stretch",
 }
})

export default Med;
