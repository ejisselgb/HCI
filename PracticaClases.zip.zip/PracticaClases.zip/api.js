var apiurl = "http://www.omdbapi.com/?apikey=2cbac9d4&";

function infoMovie(){
	console.log("holamundo")
	var data =  document.getElementById("Pelicula").value 
	p = getInfoMovie(apiurl,"t="+ data)
	p.then((resolve)=>{
		console.log(resolve.Title)	
	})
};

function getInfoMovie(url, string){
  return new Promise(function(resolver, reject){
        var request = new XMLHttpRequest();
	request.open('GET',url + string, true);
	request.onload = function(){
			var data = JSON.parse(this.response);
			console.log(data);
	};
	request.send();});
};







